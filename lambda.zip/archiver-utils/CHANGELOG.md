## Changelog

**2.0.0-wip** — <small> August 22, 2018 </small> — [Diff](https://github.com/archiverjs/archiver-utils/compare/1.3.0...master)

- breaking: follow node LTS, remove support for versions under 6.
- other: remove unused lodash dependence (#13)
- test: now targeting node v10

[Release Archive](https://github.com/archiverjs/archiver-utils/releases)