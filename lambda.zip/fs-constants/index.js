module.exports = require('fs').constants || require('constants')
