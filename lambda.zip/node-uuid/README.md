# node-uuid

DEPRECATED: Use the `uuid` package instead.  See

* On NPM: https://www.npmjs.com/package/uuid
* On Github: https://github.com/kelektiv/node-uuid

(Yes, the github project is still called "node-uuid". We merged the two projects. Sorry for the confusion.)
